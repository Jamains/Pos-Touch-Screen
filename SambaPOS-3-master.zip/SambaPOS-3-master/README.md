#SambaPOS Touch Screen POS Software

More Information
http://emreeren.github.com/SambaPOS-3/

Visit www.sambapos.com for stable releases.