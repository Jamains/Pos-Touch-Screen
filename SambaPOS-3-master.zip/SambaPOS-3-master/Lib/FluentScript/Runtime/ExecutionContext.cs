﻿namespace Fluentscript.Lib.Runtime
{
    /// <summary>
    /// Context class for executing the code.
    /// </summary>
    public class ExecutionContext
    {
    }
}
