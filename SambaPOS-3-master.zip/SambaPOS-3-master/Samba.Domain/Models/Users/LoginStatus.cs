﻿
namespace Samba.Domain.Models.Users
{
    public enum LoginStatus
    {
        CanLogin,
        PinNotFound,
        Suspended
    }
}
